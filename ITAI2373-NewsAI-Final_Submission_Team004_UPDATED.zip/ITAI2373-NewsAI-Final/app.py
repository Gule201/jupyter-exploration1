import streamlit as st
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib
import re, string
from langdetect import detect
from deep_translator import GoogleTranslator

st.set_page_config(page_title="News AI Platform", layout="wide")
st.title("News AI Platform — Streamlit (Bonus)")

# Load artifacts or instruct user
@st.cache_resource
def load_model():
    try:
        return joblib.load("artifacts/final_best_model.joblib")
    except:
        return None

model = load_model()

def clean_text(t):
    t = re.sub(r'https?://\S+|www\.\S+',' ', t)
    t = re.sub(r'<.*?>',' ', t)
    t = t.translate(str.maketrans('', '', string.punctuation))
    t = re.sub(r'\b\d+\b',' ', t)
    t = re.sub(r'\s+',' ', t).strip().lower()
    return t

def detect_lang(text):
    try:
        return detect(text)
    except:
        return "unknown"

def to_english(text, src=None):
    try:
        if not src:
            src = detect_lang(text)
        if src not in ("en","unknown"):
            return GoogleTranslator(source=src, target="en").translate(text)
        return text
    except:
        return text

query = st.text_area("Paste an article or query:")
if st.button("Analyze"):
    if len(query.strip())==0:
        st.warning("Enter some text to analyze.")
    else:
        lang = detect_lang(query)
        text_en = to_english(query, lang)
        st.write(f"Detected language: **{lang}**")
        if model:
            try:
                pipe = model
                pred = pipe.predict([text_en])[0]
                st.success(f"Predicted category: **{pred}**")
            except Exception as e:
                st.error(f"Model error: {e}")
        else:
            st.info("Model artifact not found. Run the notebook to generate artifacts first.")
        st.subheader("Preview")
        st.write(text_en[:1000])
