# ITAI2373 — Final Project: News AI Platform (Team004, Solo)

**Submitter:** Esther Odaibo  
**Group:** Team004 (solo)  
**Folder:** `ITAI2373-NewsAI-Final`  
**Notebook:** `FinalProject_NewsAI_Platform.ipynb`

## What this delivers
- Advanced classification + topic modeling (LDA)
- Sentiment + extractive summarization
- Multilingual detection + translation to English
- Semantic search (TF-IDF cosine)
- NER (spaCy)
- Gradio conversational interface for interactive analysis
- Saved artifacts for reproducibility

## How to run (Colab)
1. Open the notebook in Google Colab.
2. Run **Setup** section.
3. Load dataset via Kaggle helpers or manual CSV upload.
4. Execute cells top-to-bottom.
5. (Optional) uncomment `demo.launch()` to start the Gradio app.

## Deliverables (per instructions)
- GitHub link to your public portfolio repo containing this folder
- Technical Documentation PDF
- Executive Summary PDF
- Team Presentation (PowerPoint **or** Video)
- Team Reflective Journal (one per group)

## File Naming (team submissions)
- `FP_TechnicalDoc_EstherOdaibo_Team004_ITAI2373.pdf`
- `FP_ExecutiveSummary_EstherOdaibo_Team004_ITAI2373.pdf`
- `FP_Presentation_EstherOdaibo_Team004_ITAI2373.pptx` (or `...mp4`)
- `FP_ReflectiveJournal_Team004_ITAI2373.pdf`

## Notes
- Keep dataset ≤ 2000 rows; obtain instructor approval for dataset
- If translation fails (rate limiting), pipeline falls back to original text


## Selected Submission Details (pre-filled)
- **Portfolio Repo URL:** https://github.com/Gule201/ITAI2373-Portfolio
- **Dataset:** BBC News Classification (learn-ai-bbc) (https://www.kaggle.com/competitions/learn-ai-bbc/data)
- **Primary CSV:** `bbc/train.csv`
- **Frontend:** Yes — include Gradio (primary) and Streamlit scaffold (bonus)
- **Multilingual test languages:** Spanish (es), French (fr), Portuguese (pt)
- **Presentation format:** PowerPoint (included)
